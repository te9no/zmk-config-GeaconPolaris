# Polaris ZeroShift main 統合版

ソース cf1dfe8802c3f7ef68519f1a7aed5fb9ebee70d3。左右とも xiao_ble//zmk 用。左右別に対応する UF2 を書き込みます。左右ビルド、UF2 ブロック、SHA-256、設定と依存のクリーン状態を確認しました。統合版の実機・Renode 再試験は未実施。
